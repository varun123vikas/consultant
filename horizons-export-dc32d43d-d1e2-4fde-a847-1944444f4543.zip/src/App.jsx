
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import HomePage from '@/pages/HomePage';
import ProfessionalsPage from '@/pages/ProfessionalsPage';
import AboutPage from '@/pages/AboutPage';

function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'professionals':
        return <ProfessionalsPage />;
      case 'about':
        return <AboutPage />;
      case 'home':
      default:
        return <HomePage setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900">
      <Helmet>
        <title>Schoolar - Connect with Expert Professionals</title>
        <meta name="description" content="Connect with verified professionals for expert consultations. Book video calls, chat sessions, and get professional advice from doctors, engineers, lawyers, and more." />
      </Helmet>

      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main>
        {renderContent()}
      </main>

      <Footer />
      <Toaster />
    </div>
  );
}

export default App;

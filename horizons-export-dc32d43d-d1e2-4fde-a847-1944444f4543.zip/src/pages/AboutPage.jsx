
import React from 'react';
import { motion } from 'framer-motion';
import { companyValues } from '@/data/mockData';

const AboutPage = () => {
  return (
    <section className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            About Schoolar
          </h1>
          <p className="text-xl text-white/70 leading-relaxed">
            We're revolutionizing professional consultations by connecting people with verified experts across multiple industries through cutting-edge technology.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl font-bold text-white mb-6">Our Mission</h2>
            <p className="text-white/70 leading-relaxed mb-6">
              To democratize access to professional expertise by creating a seamless platform where anyone can connect with verified professionals for high-quality consultations, regardless of location or time constraints.
            </p>
            <p className="text-white/70 leading-relaxed">
              We believe that expert advice should be accessible, affordable, and available when you need it most.
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <img  alt="Team of diverse professionals collaborating" class="w-full h-64 object-cover rounded-2xl" src="https://images.unsplash.com/photo-1573165231977-3f0e27806045" />
          </motion.div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {companyValues.map((value, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <value.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{value.title}</h3>
              <p className="text-white/70">{value.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutPage;


import React from 'react';
import { motion } from 'framer-motion';
import { Video, MessageCircle, Calendar, Star, Clock, Shield, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { features, stats } from '@/data/mockData';
import * as LucideIcons from 'lucide-react';

const handleVideoCall = () => {
  toast({
    title: "🚧 Video Call Feature Coming Soon!",
    description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    duration: 4000,
  });
};

const HeroSection = ({ setActiveTab }) => (
  <section className="relative py-20 px-4 overflow-hidden">
    <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-3xl"></div>
    <div className="max-w-7xl mx-auto relative z-10">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-8"
        >
          <h1 className="text-5xl lg:text-7xl font-bold text-white leading-tight">
            Connect with
            <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent"> Expert </span>
            Professionals
          </h1>
          <p className="text-xl text-white/80 leading-relaxed">
            Get instant access to verified professionals across healthcare, engineering, legal, business, and education. Book video consultations, chat sessions, or schedule appointments.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              size="lg"
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-lg px-8 py-6"
              onClick={() => setActiveTab('professionals')}
            >
              Find Professionals
              <ChevronRight className="ml-2 w-5 h-5" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white/20 text-white hover:bg-white/10 text-lg px-8 py-6"
              onClick={handleVideoCall}
            >
              <Video className="mr-2 w-5 h-5" />
              Start Video Call
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <div className="relative z-10 bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20">
            <img  alt="Professional consultation video call interface" class="w-full h-64 object-cover rounded-2xl" src="https://images.unsplash.com/photo-1655127282965-049dce345765" />
            <div className="mt-6 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white font-semibold">Dr. Sarah Johnson</p>
                  <p className="text-white/60 text-sm">Cardiologist • Available Now</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button size="icon" className="bg-green-500 hover:bg-green-600">
                  <Video className="w-5 h-5" />
                </Button>
                <Button size="icon" variant="outline" className="border-white/20 text-white">
                  <MessageCircle className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
          <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full blur-xl opacity-60"></div>
          <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full blur-xl opacity-60"></div>
        </motion.div>
      </div>
    </div>
  </section>
);

const FeaturesSection = () => (
  <section className="py-20 px-4">
    <div className="max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center mb-16"
      >
        <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
          Why Choose Schoolar?
        </h2>
        <p className="text-xl text-white/70 max-w-3xl mx-auto">
          Experience seamless professional consultations with our cutting-edge platform
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature, index) => {
          const Icon = LucideIcons[feature.icon];
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-lg rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-300 group"
            >
              <div className={`w-16 h-16 bg-gradient-to-r ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                {Icon && <Icon className="w-8 h-8 text-white" />}
              </div>
              <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
              <p className="text-white/70 leading-relaxed">{feature.description}</p>
            </motion.div>
          );
        })}
      </div>
    </div>
  </section>
);

const StatsSection = () => (
  <section className="py-20 px-4 bg-black/20">
    <div className="max-w-7xl mx-auto">
      <div className="grid md:grid-cols-4 gap-8 text-center">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            className="space-y-2"
          >
            <div className="text-4xl lg:text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              {stat.number}
            </div>
            <div className="text-white/70 text-lg">{stat.label}</div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const HomePage = ({ setActiveTab }) => {
  return (
    <>
      <HeroSection setActiveTab={setActiveTab} />
      <FeaturesSection />
      <StatsSection />
    </>
  );
};

export default HomePage;

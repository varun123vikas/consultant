
import React from 'react';
import { Users, Phone, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-black/40 backdrop-blur-lg border-t border-white/10 py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Schoolar</span>
            </div>
            <p className="text-white/60">
              Connecting you with verified professionals for expert consultations worldwide.
            </p>
            <div className="flex space-x-4">
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer">
                <Mail className="w-5 h-5 text-white" />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer">
                <Phone className="w-5 h-5 text-white" />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer">
                <MapPin className="w-5 h-5 text-white" />
              </div>
            </div>
          </div>

          <div>
            <span className="text-lg font-semibold text-white mb-4 block">Services</span>
            <div className="space-y-2">
              {['Healthcare Consultations', 'Engineering Support', 'Legal Advice', 'Business Consulting', 'Educational Tutoring'].map((service) => (
                <p key={service} className="text-white/60 hover:text-white transition-colors cursor-pointer">{service}</p>
              ))}
            </div>
          </div>

          <div>
            <span className="text-lg font-semibold text-white mb-4 block">Company</span>
            <div className="space-y-2">
              {['About Us', 'Careers', 'Press', 'Blog', 'Contact'].map((item) => (
                <p key={item} className="text-white/60 hover:text-white transition-colors cursor-pointer">{item}</p>
              ))}
            </div>
          </div>

          <div>
            <span className="text-lg font-semibold text-white mb-4 block">Support</span>
            <div className="space-y-2">
              {['Help Center', 'Privacy Policy', 'Terms of Service', 'Cookie Policy', 'Security'].map((item) => (
                <p key={item} className="text-white/60 hover:text-white transition-colors cursor-pointer">{item}</p>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 text-center">
          <p className="text-white/60">
            © 2025 Schoolar. All rights reserved. Built with ❤️ for connecting professionals worldwide.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;


import { Users, Shield, Award } from 'lucide-react';
import { Scale, Briefcase, GraduationCap } from '@/components/icons';

export const categories = [
    { id: 'all', name: 'All Professionals', icon: Users, color: 'from-purple-500 to-pink-500' },
    { id: 'healthcare', name: 'Healthcare', icon: Shield, color: 'from-blue-500 to-cyan-500' },
    { id: 'engineering', name: 'Engineering', icon: Award, color: 'from-green-500 to-emerald-500' },
    { id: 'legal', name: 'Legal', icon: Scale, color: 'from-orange-500 to-red-500' },
    { id: 'business', name: 'Business', icon: Briefcase, color: 'from-indigo-500 to-purple-500' },
    { id: 'education', name: 'Education', icon: GraduationCap, color: 'from-yellow-500 to-orange-500' }
];

export const professionals = [
    {
      id: 1,
      name: 'Dr. Sarah Johnson',
      specialty: 'Cardiologist',
      category: 'healthcare',
      rating: 4.9,
      experience: '15 years',
      price: 150,
      availability: 'Available Now',
      consultations: 2500,
      languages: ['English', 'Spanish']
    },
    {
      id: 2,
      name: 'John Smith',
      specialty: 'Software Engineer',
      category: 'engineering',
      rating: 4.8,
      experience: '10 years',
      price: 120,
      availability: 'Available in 30 min',
      consultations: 1800,
      languages: ['English', 'French']
    },
    {
      id: 3,
      name: 'Maria Rodriguez',
      specialty: 'Corporate Lawyer',
      category: 'legal',
      rating: 4.9,
      experience: '12 years',
      price: 200,
      availability: 'Available Tomorrow',
      consultations: 1200,
      languages: ['English', 'Spanish', 'Portuguese']
    },
    {
      id: 4,
      name: 'Dr. Michael Chen',
      specialty: 'Dermatologist',
      category: 'healthcare',
      rating: 4.7,
      experience: '8 years',
      price: 130,
      availability: 'Available Now',
      consultations: 1500,
      languages: ['English', 'Mandarin']
    },
    {
      id: 5,
      name: 'Emily Davis',
      specialty: 'Business Consultant',
      category: 'business',
      rating: 4.8,
      experience: '14 years',
      price: 180,
      availability: 'Available in 1 hour',
      consultations: 2200,
      languages: ['English', 'German']
    },
    {
      id: 6,
      name: 'Prof. Robert Wilson',
      specialty: 'Mathematics Tutor',
      category: 'education',
      rating: 4.9,
      experience: '20 years',
      price: 80,
      availability: 'Available Now',
      consultations: 3000,
      languages: ['English']
    }
];

export const features = [
  {
    icon: 'Video',
    title: 'HD Video Consultations',
    description: 'Crystal clear video calls with screen sharing and recording capabilities',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    icon: 'MessageCircle',
    title: 'Real-time Chat',
    description: 'Instant messaging with file sharing and voice notes support',
    color: 'from-green-500 to-emerald-500'
  },
  {
    icon: 'Calendar',
    title: 'Smart Scheduling',
    description: 'AI-powered appointment booking with automatic reminders',
    color: 'from-purple-500 to-pink-500'
  },
  {
    icon: 'Shield',
    title: 'Verified Professionals',
    description: 'All professionals are thoroughly vetted and certified',
    color: 'from-orange-500 to-red-500'
  },
  {
    icon: 'Clock',
    title: '24/7 Availability',
    description: 'Access professionals around the clock for urgent consultations',
    color: 'from-indigo-500 to-purple-500'
  },
  {
    icon: 'Star',
    title: 'Quality Assurance',
    description: 'Rating system and quality monitoring for best experience',
    color: 'from-yellow-500 to-orange-500'
  }
];

export const stats = [
  { number: '50K+', label: 'Active Professionals' },
  { number: '1M+', label: 'Consultations Completed' },
  { number: '4.9/5', label: 'Average Rating' },
  { number: '24/7', label: 'Support Available' }
];

export const companyValues = [
  {
    title: 'Quality First',
    description: 'Every professional undergoes rigorous verification and continuous quality monitoring.',
    icon: Shield
  },
  {
    title: 'Innovation Driven',
    description: 'We leverage cutting-edge technology to provide the best consultation experience.',
    icon: Award
  },
  {
    title: 'Global Reach',
    description: 'Connect with professionals worldwide, breaking geographical barriers.',
    icon: Users
  }
];
